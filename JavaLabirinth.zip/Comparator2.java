import cellTypes.*;
/**
 * Comparator2 implementeaza un comparator.
 * @author Seby97
 *
 */

public class Comparator2 implements java.util.Comparator<Cell> {
	
	/**
	 * Metoda va fi folosita pentru ca in urma sortarii colectia sa arate astfel:
	 * la inceput vor fi sortate crescator dupa prioritate toate celule 
	 * de tip ObstacleCell si OutCell(nu se va face distinctie intre ele).
	 * Dupa acestea vor fi sortate toate elem. ramase(de celelalte tipuri) descrescator 
	 * dupa noVisits.
	 * In caz ca exista o celula de tip FinishCell,ea va fi plasata in capatul colectiei.
	 * @param one prima celula.
	 * @param two a doua celula.
	 * @return un intreg.
	 * 
	 */

	@Override
    public int compare(Cell one,Cell two){
		
	
        //conditiile ne asigura ca FinishCell va fi in capatul colectiei sortate
        if(two instanceof FinishCell)
            return -1;
        if(one instanceof FinishCell)
            return 1;
        
        //daca one si two sunt amandoua de tipul OutCell sau ObstacleCell(nu ineaparat la fel)
        //sortam crescator dupa prioritate
		if((one instanceof ObstacleCell||one instanceof OutCell)
		    &&(two instanceof ObstacleCell||two instanceof OutCell))
		        		
			    return one.priority-two.priority;
		
		//daca doar unul din ele e de tipul ObstacleCell sau OutCell il aducem la inceputul colectiei
		if((one instanceof ObstacleCell||one instanceof OutCell))
			return -1;
		if((two instanceof ObstacleCell||two instanceof OutCell))
			return 1;
		
		        
        //daca sunt amandoua diferite de FinishCell,ObstacleCell si OutCell
		//sortam descr dupa numarul de visite si in caz de egalitate crescator 
		//dupa prioritate
        int x = two.noVisits - one.noVisits;
        if (x!=0)
            return x;
        
        return  (one.priority - two.priority);

    }
}
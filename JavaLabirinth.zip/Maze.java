import cellTypes.*;
import exceptions.*;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.util.*;
/**
 * Maze e clasa care contine labirintul si rezolva task1,respectiv task2.
 * @author Seby97
 *
 */
public class Maze {
    Cell[][] matrix; //matricea ce reprezinta labirintul.
    public int height;//numarul de linii.
    public int width;//numarul de coloane.
    private Cell currentCell;//adresa celulei curente(ea va reprezenta pozitia in matrix[][]).
    private Cell startCell;//adresa celulei de intrare.
    private Cell finishCell;//adresa celulei de iesire.
    int orientation=0;//orientarea eroului e 0.(se va detalia ulterior).
    //cei 2 vectori sunt vectorii de directie pentru a verifica vecinii din matrix[][]
    //in ordinea E,N,V,S in matrice(mereu la fel,nu depinde de orientarea eroului).
    int x[] = {0,-1,0,1}; 
    int y[] = {1,0,-1,0};
    //adresa unde scriem rezultatele
    PrintWriter out = null;

    /**
     * Constructor care primeste adresa de la care citeste si
     * actualizeaza campurile aferente labirintului.
     * @param in adresa de la care citim "labirintul"
     * @throws Exception IOException
     */
    public Maze(BufferedReader in) throws Exception {
        String firstLine = in.readLine();
        String[] tokens = firstLine.split("[ ]+");

        height = Integer.parseInt(tokens[0]) ;
        width = Integer.parseInt(tokens[1]);
        matrix = new Cell[height][width];


        for (int i = 0; i < height ; i++) {
            String line = in.readLine();
            for (int j = 0; j < width ; j++) {

                matrix[i][j] = CellFactory.getCell(line.charAt(j));
                matrix[i][j].x = i;
                matrix[i][j].y = j;

                if (matrix[i][j] instanceof StartCell)
                    startCell = matrix[i][j];
                if (matrix[i][j] instanceof FinishCell)
                    finishCell = matrix[i][j];

            }
        }
       
    }
    
   

   /**
    * Returneaza vecinii lui currentCell.
    * @return lista de vecini a lui currentCell
    * (atat cei din matrice cat si vecini de tipul OutCell 
    * in cazul in care e la marginea labirintului).
    */
    
    //    2        1        0        3         ^ inseamna orientation=0 
    //  1 ^ 3    0 > 2    3 v 1    2 < 0  unde > inseamna orientation=1  ,iar numerele sunt
    //    0        3        2        1         v inseamna orientation=2   prioritatile vecinilor.
    //										   < inseamna orientation=3
   
    public LinkedList<Cell> getNeighbours() {
        
    	LinkedList<Cell> list = new LinkedList<Cell>();
        int i = currentCell.x;
        int j = currentCell.y;

        int coefficient = 7;

        //setam prioritatile vecinilor
        for(int k=0;k<4;k++){
        	//daca sunt afara
        	if(!(i+x[k]>=0&&i+x[k]<height&&j+y[k]>=0 &&j+y[k]<width))
        	{
        		OutCell outCell = new OutCell();
        		//setam prioritatea
        		outCell.priority = (coefficient - orientation) %4;
        		//adaugam in lista de vecini
        		list.add(outCell);
        	}
        	//altfel
        	else{
        		//setam prioritatea
        	    matrix[i + x[k]][j + y[k]].priority = (coefficient - orientation) % 4;
        	    //adaugam in lista de vecini
                list.add(matrix[i + x[k]][j + y[k]]);
            }
        	
            coefficient--;
        }
        return list;
    }

    /**
     * Actualizeaza orientation.Verifica currentCell si parametrul pentru a 
     * vedea cum se modifica orientarea
     * @param nextCell celula spre care "va pleca" eroul
     */
    public void getOrientation(Cell nextCell) {
    	//sunt pe aceeasi linie
        if (currentCell.x == nextCell.x) {
            if (currentCell.y + 1 == nextCell.y)
                orientation = 1;
            else
            	orientation = 3;
        }
        //nu sunt pe aceeasi linie
        else if (currentCell.x < nextCell.x)
            	orientation = 2;
        else
            	orientation = 0;

    }
    /**
     * Metoda care arunca si prinde o exceptie de tipul HeroOutOfGroundException sau
     * CannotMoveIntoWallsException cand cell e de tipul OutCell,respectiv ObstacleCell.
     * @param cell celula asupra careia se vor aplica cele de mai sus.
     */
    public void exceptions(Cell cell){
    	try{
    		if(cell instanceof OutCell)
    			throw new HeroOutOfGroundException();
    		else if(cell instanceof ObstacleCell)
    			throw new CannotMoveIntoWallsException();
    	   }catch(Exception e){}
    }

    /**
     * Actualizeaza currentCell cu pozitia urmatoare ,conform algoritmului de la task1.
     * @param version 1 daca dorim sa se printeze pozitia curenta si exceptiile rezultate
     * pana sa dam de pozitia urmatoare,respectiv 0 daca nu dorim acest lucru
     * (vom avea nevoie pentru a afla mai intai lungimea drumului).
     */
    public void getNextPosition(int version){
    	//creeaza lista de vecini.
        LinkedList<Cell> listNeighbours = getNeighbours();
        //creeaza o copie a acestei liste.
    	LinkedList<Cell> newList = (LinkedList<Cell>) listNeighbours.clone();
    	//sortam copia listei.Acum avem copia listei sortata dupa prioritate.
        Collections.sort(newList,new Comparator1());

        if(version == 1)
        	out.println(currentCell.x +" " +currentCell.y);
        
        //cat timp in lista dam de celule de tipul OutCell sau ObstacleCell
        //afisam/nu afisam exceptiile le scoatem din lista. 
        Cell cell = null; 
              while( newList.getLast() instanceof OutCell 
            		  || newList.getLast() instanceof ObstacleCell){
        		 cell = newList.pollLast();
        	
        	//trebuie decomentat pentru a afisa in timp real si exceptiile	 
        	//	if(version == 1)
        	//		exceptions(cell);
        		
        	  }
             
              //sortam noua lista obtinuta dupa Comparator2
        Collections.sort(newList,new Comparator2());
        //primul element este cel care va reprezenta pozitia viitoare
        //totusi,el este doar o copie a celui care pointeaza la matrix[][]
        //trebuie deci sa gasim corespondentul din matrix[][].
        cell = newList.pollLast();
       
        //gasim corespondentul din matrix[][]
        Iterator<Cell> iterator = listNeighbours.iterator();
        while (iterator.hasNext()){
            Cell aux = iterator.next();
            if (aux.x == cell.x && aux.y == cell.y) {
            	//actualizam orientarea
                getOrientation(aux);
                //actualizam pozitia eroului
                currentCell = aux;
                //daca am intrat in celula de tip FinishCell si version=1 scriem in fisier coord.
                if(currentCell instanceof FinishCell && version == 1)
                	out.print(currentCell.x + " " +currentCell.y);
            }
        }
    }
    
    /**
     * actualizeaza numarul de vizite ale elementelor din matrice cu 0;
     */
    public void refacereMatrice(){
    	orientation = 0 ;
    	for(int i=0;i<height;i++)
    		for(int j=0;j<width;j++)
    			matrix[i][j].noVisits = 0;
    }
      

    public void task1(){
    	//setam pozitia initiala a eroului alaturi de orientarea sa
    	    orientation = 0 ;
    		currentCell = startCell;
    		
    		//numarul de mutari=0;
            int noMoves=0;
            
            //parcurgem labirintul conform algoritmului pana cand dam de FinishCell
            //si incrementam la fiecare pas noMoves.
            while (!(currentCell instanceof FinishCell)) {
                noMoves++;
                currentCell.noVisits++;
                getNextPosition(0);
            }
            
            //incrementam pentru a obtine valoarea corecta a drumului
            //luam in calcul si finishCell
            out.println(++noMoves);
            
            refacereMatrice();
            
            //mai parcurgem o data pentru a scrie drumul in out.
            currentCell = startCell;
            while (!(currentCell instanceof FinishCell)) {
                
                currentCell.noVisits++;
                getNextPosition(1);
            }
            //refacem matrice
           refacereMatrice();
    }

    
    
    
    
//------------------------------------TASK2--------------------------------------


   
    public void task2(){
        getDistances();
        RoadConfiguration();
    }
    
    /**
     * Returneaza daca putem sau nu vizita celula cell primita ca parametru.
     * @param cell celula pe care vrem sa o vizitam
     * @param visited matrice care ne va spune daca am vizitat anterior sau nu celula respectiva
     * @return true daca putem sa o vizitam,false altfel.
     */
    public boolean isValid(Cell cell, boolean[][] visited) {
        //daca e obstacol inseamna ca nu putem vizita acea celula;
    	if (cell instanceof ObstacleCell||cell instanceof OutCell)
            return false;
    	//daca visited e false inseamna ca nu a fost vizitat inca
        if(visited[cell.x][cell.y] == false)
            return true;
        //altfel
        return false;
    }
    
/**
 * Actualizeaza distantance din fiecare celula a matrix[][]
 * conform algoritmului lui Djikstra(BFS la baza).
 */
    public void getDistances() {
    	
    	//initializam coada
        LinkedList<Cell> queue = new LinkedList<>();
        //matricea de visited.initial toate elementele sunt false
        boolean[][] visited = new boolean[height][width];
        currentCell = finishCell;
        finishCell.distance=0; //distanta de la finish e 0;
        visited[currentCell.x][currentCell.y] = true;//actualizam ca visitat
        int distance=0;

        //punem in coada finishCell
        queue.addFirst(currentCell);

        //cat timp coada nu e goala
        while (!queue.isEmpty()) {
        	//creem o alta coada
            LinkedList<Cell> nextList = new LinkedList<Cell>();
            distance++;
            //pentru fiecare celula din queue o sa punem toti vecinii lor care nu au mai fost
            //vizitati in nextList,actualizand la fiecare pas campul distance.
            for(Cell cell:queue) {
            	cell.distance = distance-1;
            	
                currentCell = cell;
                LinkedList<Cell> listNeighbours = getNeighbours();
                Iterator<Cell> it = listNeighbours.iterator();
                while (it.hasNext()) {
                    Cell aux = it.next();
                    if (isValid(aux,visited)){
                        aux.distance = distance;
                        visited[aux.x][aux.y] = true;
                        nextList.addFirst(aux);
                    }
                }
            }
            //queue devine nextList
            
            queue = nextList;
        }		
        		
}
    
    /**
     * Scrie in fisier rezultatul.
     */
    public void RoadConfiguration(){
    	//daca nu avem drum
        currentCell = startCell;
        if(currentCell.distance == Integer.MAX_VALUE) {
            out.println("There is no available road");
            return;
        }

        out.println(currentCell.distance+1);

        //cat timp nu suntem in FinishCell
        while(!(currentCell instanceof FinishCell)) {
            LinkedList<Cell> listNeighbours = getNeighbours();
            Iterator<Cell> iterator = listNeighbours.iterator();
            //pentru fiecare vecin a lui currentCell
            while (iterator.hasNext()) {
                Cell cell = iterator.next();
                //lista de vecini e conform prioritatilor(in ordine descrescatoare).
                //daca cell e din matrice si distance e cu 1 mai mic decat currentCell
                //currentCell==cell;
                if (!(cell instanceof ObstacleCell||cell instanceof OutCell) 
                	&&cell.distance == currentCell.distance - 1) {
                    out.println(currentCell.x + " " + currentCell.y);
                    currentCell = cell;
                    break;
                }
            }
        }
        //afisam finishCell
        out.println(currentCell.x + " " +currentCell.y);
    }
}

import java.io.*;

public class Main {
    public static void main(String[] args) {
        try {
            BufferedReader in = new BufferedReader(new FileReader(args[1]));
            PrintWriter out = new PrintWriter(args[2]);
            
            //actualizam matricea din maze
            Maze maze = new Maze(in);
            //actualizam campul PrintWriter din maze,adresa la
            //care vom printa informatiile.
            maze.out=out;
	    
            //daca primul argument este 1 apelam primul task.
            if(Integer.parseInt(args[0]) == 1)
           	 maze.task1();
            //daca primul argument este 2 apelam al doilea task.
            if(Integer.parseInt(args[0]) == 2)
                 maze.task2();
		    //daca primim argument nu este 1 sau 2 aruncam Exception.
            if(Integer.parseInt(args[0])<=0||Integer.parseInt(args[0])>2)
            	throw new Exception();
            
            		
            out.close();  
        	
        } catch (Exception e){ 
        System.out.println("Nu am putut deschide fisierul dat ca input sau"
        		+ "numarul taskului nu este corect.Verificati!");	
        }
    }
}

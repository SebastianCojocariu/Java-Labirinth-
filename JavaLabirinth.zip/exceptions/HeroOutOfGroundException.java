package exceptions;
/**
 * HeroOutOfGroundException extinde Exception.
 * @author Seby97
 *
 */
public class HeroOutOfGroundException extends Exception {
	private static final long serialVersionUID = -7246055381107798834L;

	public HeroOutOfGroundException(){
        System.out.println("Hero reached OutOfGround Exception");
    }
}

package exceptions;
/**
 * CannotMoveIntoWallsException extinde Exception.
 * @author Seby97
 *
 */
public class CannotMoveIntoWallsException extends Exception {
	private static final long serialVersionUID = 1L;

	public CannotMoveIntoWallsException(){
        System.out.println("Hero reached a Wall!");
    }
}

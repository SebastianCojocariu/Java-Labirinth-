import cellTypes.*;
/**
 * Comparator1 implementeaza un comparator care sorteaza crescator 
 * dupa prioritatea din fiecare Cell.
 * @author Seby97
 *
 */
public class Comparator1 implements java.util.Comparator<Cell> {

	/**
	 * Returneaza diferenta de prioritati din prima celula si a 2a celula.
	 * @param one prima celula.
	 * @param two a doua celula.
	 * @return >0 daca one.priority > two.priority,0 daca sunt egale si <0 altfel.
	 * 
	 */
	@Override
    public int compare(Cell one,Cell two){
		
		return one.priority - two.priority;

    }
}
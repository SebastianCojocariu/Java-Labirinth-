package cellTypes;
/**
 * Cell clasa ce retine informatiile unei celule din matricea primita ca input
 * (x,y) sunt coordonatele in matrice.
 * prioritatea reprezinta prioritatea la un moment dat a celulei in raport cu o lista de vecini
 * a nodului current.
 * noVisits reprezinta numarul de vizite in celula de-a lungul algoritmului de la task1.
 * distance reprezinta distanta minima de la celula la celula FinishCell 
 * ce va fi calculata la task2.
 * @author Seby97
 *
 */

public abstract class Cell{
    public int x;
    public int y;
    public int priority;
    public int noVisits=0;
    public int distance=Integer.MAX_VALUE;
}
package cellTypes;
/**
 * FreeCell extinde Cell si reprezinta o celula libera din matrix[][].
 * @author Seby97
 *
 */
public class FreeCell extends Cell {
	/*public FreeCell(){
		
		x = -1;
		y = -1;
	}*/
}

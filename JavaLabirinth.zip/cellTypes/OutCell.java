package cellTypes;
/**
 * OutCell extinde Cell si reprezinta o celula din afara matrix[][].
 * @author Seby97
 *
 */
public class OutCell extends Cell{
	//initializam coordonatele cu (-1,-1) pentru a nu exista
	//confuzie cu matrix[0][0](care va avea x=0 si y=0).
	public OutCell(){
		x = -1;
		y = -1;
	}

}

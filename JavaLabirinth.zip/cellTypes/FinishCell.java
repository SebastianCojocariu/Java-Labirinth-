package cellTypes;
/**
 * FinishCell extinde Cell si reprezinta celula de iesire din matrix[][].
 * @author Seby97
 *
 */
public class FinishCell extends Cell {
}

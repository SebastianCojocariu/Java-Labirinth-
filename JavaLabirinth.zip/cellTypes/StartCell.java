package cellTypes;
/**
 * StartCell extinde Cell si reprezinta celula de intrare in matrix[][].
 * @author Seby97
 *
 */
public class StartCell extends Cell {
}

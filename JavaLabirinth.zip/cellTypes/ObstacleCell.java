package cellTypes;
/**
 * ObstacleCell extinde Cell si reprezinta un obstacol in matrix[][].
 * @author Seby97
 *
 */

public class ObstacleCell extends Cell {
}

import cellTypes.*;
/**
 * CellFactory este o fabrica de Cell-uri(asemeni FactoryPattern).
 * @author Seby97
 *
 */
public class CellFactory {
	/**
	 * 
	 * @param s '.'=FreeCell,'#'=ObstacleCell,'I'=StartCell,'O'=FinishCell.
	 * @return tipul de Cell specificata de s.
	 */
    public static Cell getCell(char s){
        if(s == 'I')
            return new StartCell();
        if(s == 'O')
            return new FinishCell();
        if(s == '#')
            return new ObstacleCell();
        if(s == '.')
            return new FreeCell();

        return null;
    }
}
